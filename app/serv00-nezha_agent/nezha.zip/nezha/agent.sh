#!/bin/sh

export TMPDIR=/home/wm8/nezha/tmp

/home/wm8/nezha/agent -s tz.okpay.cf:24885 -p fVo7pvpquXUczO3VgL -d > /dev/null 2>&1 &
